package com.cg.project.bean;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "PE")
public class PEmployee extends Employee {
	public PEmployee(int employeeId, String name, String emailId) {
		super(employeeId, name, emailId);
	}

	private int hra, ta, da;

	/**
	 * @param employeeId
	 * @param name
	 * @param emailId
	 * @param hra
	 * @param ta
	 * @param da
	 */

	public PEmployee(int employeeId, String name, String emailId, int hra,
			int ta, int da) {
		super(employeeId, name, emailId);
		this.hra = hra;
		this.ta = ta;
		this.da = da;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}

	@Override
	public String toString() {
		return "PEmployee [hra=" + hra + ", ta=" + ta + ", da=" + da + "]";
	}

}
